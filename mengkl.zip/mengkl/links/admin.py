from django.contrib import admin

from links.models import Friend

# Register your models here.
admin.site.register(Friend)
