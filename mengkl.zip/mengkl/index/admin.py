from django.contrib import admin

from .models import Myapps

# Register your models here.

admin.site.register(Myapps)
