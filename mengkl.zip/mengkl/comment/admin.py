from django.contrib import admin

from comment.models import Comments

# Register your models here.

admin.site.register(Comments)
